package hmtdemo.hmt.com.hmtdemo.hmt;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.tendcloud.tenddata.TCAgent;
import com.umeng.analytics.MobclickAgent;

/**
 * Created by renbo on 2017/6/23.
 */

public class BaseActivity extends Activity {

    public String TAG = getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("BaseActivity", "onCreate" + TAG);
        Log.d("BaseActivity", "Constants.RUNNING_TIME:" + Constants.RUNNING_TIME);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("BaseActivity", "onResume" + TAG);
        String testMode = (String) SPUtils.get(this, Constants.TEST_MODE, "0");
        if (testMode.equals("1")) {
            MobclickAgent.onResume(this);
        } else if (testMode.equals("2")) {
            TCAgent.onPageStart(this, ((Activity) this).getClass().getSimpleName());
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("BaseActivity", "onPause" + TAG);
        String testMode = (String) SPUtils.get(this, Constants.TEST_MODE, "0");
        Log.d("BaseActivity", "testMode = " + testMode);
        if (testMode.equals("1")) {
            MobclickAgent.onPause(this);
        } else if (testMode.equals("2")) {
            TCAgent.onPageEnd(this, ((Activity) this).getClass().getSimpleName());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("BaseActivity", "onDestroy" + TAG);
    }

    public void unbindDrawables(View view) {
        if (view.getBackground() != null) {
            view.getBackground().setCallback(null);
        }
        if (view instanceof ViewGroup && !(view instanceof AdapterView)) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                unbindDrawables(((ViewGroup) view).getChildAt(i));
            }
            ((ViewGroup) view).removeAllViews();
        }
    }
}
