package hmtdemo.hmt.com.hmtdemo.hmt;

import android.app.Application;
import android.util.Log;

import com.growingio.android.sdk.collection.Configuration;
import com.growingio.android.sdk.collection.GrowingIO;
import com.squareup.leakcanary.LeakCanary;
import com.tendcloud.tenddata.TCAgent;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Created by renbo on 2017/6/20.
 */

public class BaseApplication extends Application {
    public static AtomicBoolean IS_FIRST = new AtomicBoolean(false);

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("BaseApplication", "BaseApplication");
        if (LeakCanary.isInAnalyzerProcess(this)) {
            // This process is dedicated to LeakCanary for heap analysis.
            // You should not init your app in this process.
            return;
        }
        LeakCanary.install(this);
        String testMode = (String) SPUtils.get(this, Constants.TEST_MODE, "0");
        if (testMode.equals("2")) {
            TCAgent.init(this);
            TCAgent.setReportUncaughtExceptions(true);
        } else if (testMode.equals("3")) {
            GrowingIO.startWithConfiguration(this, new Configuration()
                    .useID()
                    .trackAllFragments()
                    .setChannel("HMT")
                    .setDebugMode(true));
        }
    }
}
