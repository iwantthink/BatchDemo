package hmtdemo.hmt.com.hmtdemo.hmt;

import android.util.Log;

import com.hmt.analytics.util.HParams;

import java.util.HashMap;

/**
 * Created by renbo on 2017/6/22.
 */

public class Constants {

    public static final boolean IS_AUTO = false;
    public static int RUNNING_TIME = 0;
    public static int TOTAL_TIME = 100;
    public static long START_TIME = 0;
    public static long END_TIME = 0;
    public static HParams params = getParams();
    public static HashMap sHashMap = getUmeng();
    public static Throwable sThrowable = getThrowable();

    private static HParams getParams() {
        HParams params = new HParams();
        params.setParams("login", "qq");
        params.setParams("gender", "female");
        return params;
    }

    public static int REPORT_MODE = 1;
    //测试模式 0 是HMT   1是 UMENG  2是talkingData
    public final static String TEST_MODE = "test_mode";

    public static void getMemoryInfo() {
        Log.d("Constants", "Runtime.getRuntime().freeMemory():" + Runtime.getRuntime().freeMemory());
        Log.d("Constants", "Runtime.getRuntime().maxMemory():" + Runtime.getRuntime().maxMemory());
        Log.d("Constants", "Runtime.getRuntime().totalMemory():" + Runtime.getRuntime().totalMemory());
    }

    public static HashMap getUmeng() {
        HashMap mUmeng = new HashMap();
        mUmeng.put("umeng", "test");
        return mUmeng;
    }

    public static Throwable getThrowable() {
        Throwable throwable = new Throwable("获取活动信息出错");
        return throwable;
    }
}
