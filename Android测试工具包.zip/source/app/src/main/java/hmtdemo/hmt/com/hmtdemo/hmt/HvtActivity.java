package hmtdemo.hmt.com.hmtdemo.hmt;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.hmt.analytics.HVTAgent;
import com.hmt.analytics.common.HVTConstants;

import org.json.JSONObject;

import hmtdemo.hmt.com.hmtdemo.R;

public class HvtActivity extends AppCompatActivity {

    public static void start(Activity activity) {
        Intent intent = new Intent(activity, HvtActivity.class);
        activity.startActivity(intent);
        activity.finish();
    }

    private ProgressBar mPb;
    private TextView mTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hvt);
        mPb = (ProgressBar) findViewById(R.id.pb);
        mTv = (TextView) findViewById(R.id.tv_running_state);

        mPb.setVisibility(View.VISIBLE);
        mTv.setText("正在测试");
        HVTConstants.DEBUG_MODE = true;
        HVTAgent.Initialize(HvtActivity.this, Constants.REPORT_MODE);
        final HVTAgent hvtAgent = new HVTAgent(HvtActivity.this, "UA-test-android");
        hvtAgent.initVideo(new JSONObject(), new JSONObject());

        new Thread(new Runnable() {
            @Override
            public void run() {
                SystemClock.sleep(2000);
                for (int i = 0; i < Constants.TOTAL_TIME; i++) {
                    hvtAgent.send(HVTAgent.HVT_START);
                    final int finalI = i;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mTv.setText("当前运行第" + finalI + "次");
                        }
                    });
                    SystemClock.sleep(100);
                    hvtAgent.send(hvtAgent.HVT_END);
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(HvtActivity.this, "HVT测试结束", Toast.LENGTH_SHORT).show();
                        mPb.setVisibility(View.GONE);
                        mTv.setText("已经结束测试");
                    }
                });
            }
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
