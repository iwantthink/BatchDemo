package hmtdemo.hmt.com.hmtdemo.hmt;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.hmt.analytics.HMTAgent;
import com.hmt.analytics.common.CommonUtil;
import com.hmt.analytics.common.HMTConstants;
import com.hmt.analytics.util.DataBaseManager;
import com.hmt.analytics.util.DataBaseOpenHelper;
import com.tendcloud.tenddata.TCAgent;
import com.umeng.analytics.MobclickAgent;
import com.zhuge.analysis.stat.ZhugeSDK;

import hmtdemo.hmt.com.hmtdemo.R;


public class InputInfoActivity extends AppCompatActivity {

    private EditText mEtInput;
    private EditText mEtAppVersion;
    private EditText mEtSdk;
    private Button mBtnStart;
    private Button mBtnChangeVersion;
    private Button mBtnStartHVT;
    private Button mBtnChangeMode;
    private Button mBtnChangeSdk;
    private Button mBtnDatabaseNum;
    private TextView mTvReportMode;
    private Context mContext = this;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_info);
        initView();
        initListener();
    }

    @Override
    protected void onResume() {
        super.onResume();
        int mode = CommonUtil.getReportPolicyMode(mContext);
        Constants.REPORT_MODE = mode;
        mTvReportMode.setText(mode == 0 ? "当前发送模式:启动时发送" : "当前发送模式:实时发送");
        mEtAppVersion.setHint("当前AppVersion:" + CommonUtil.getAppVersion(InputInfoActivity.this));
        String testMode = (String) SPUtils.get(InputInfoActivity.this, Constants.TEST_MODE, "0");
        mEtSdk.setHint("SDK:" + testMode + " <0-HMT,1-UM,2-TD,3-GI,4-ZG>");
        switch (testMode) {
            case "0":
                mBtnStart.setText("测试HMT");
                break;
            case "1":
                mBtnStart.setText("测试UM");
                break;
            case "2":
                mBtnStart.setText("测试TD");
                break;
            case "3":
                mBtnStart.setText("测试GI");
                break;
            case "4":
                mBtnStart.setText("测试ZG");
                break;
            default:
                mBtnStart.setText("测试HMT");
                break;
        }
    }

    @Override
    protected void onDestroy() {
        mEtInput = null;
        mBtnStartHVT = null;
        mBtnStart = null;
        mBtnChangeMode = null;
        mTvReportMode = null;
        mContext = null;
        mEtAppVersion = null;
        mBtnChangeVersion = null;
        super.onDestroy();
    }

    private void initListener() {
        mBtnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Constants.RUNNING_TIME = 0;
                String str = mEtInput.getText().toString();
                if (TextUtils.isEmpty(str)) {
                    Constants.TOTAL_TIME = 100;
                    Toast.makeText(InputInfoActivity.this, "测试次数为默认的100次", Toast.LENGTH_SHORT).show();
                } else {
                    int times = Integer.valueOf(str);
                    Constants.TOTAL_TIME = times;
                    Toast.makeText(InputInfoActivity.this, "测试次数为 " + times + " 次", Toast.LENGTH_SHORT).show();
                }

                //        String[] strArr = new String[2];
                //        strArr[0] = "androidid";
                //        strArr[1] = "androidid1";
                String testMode = (String) SPUtils.get(InputInfoActivity.this, Constants.TEST_MODE, "0");
                Toast.makeText(mContext, "mode = " + testMode, Toast.LENGTH_SHORT).show();
                if (testMode.equals("0")) {
                    HMTConstants.DEBUG_MODE = true;
                    HMTAgent.Initialize(mContext, Constants.REPORT_MODE);
                    HMTAgent.onError(mContext); //监控页面错误信息
                } else if (testMode.equals("2")) {
                    TCAgent.LOG_ON = true;
                } else if (testMode.equals("4")) {
                    ZhugeSDK.getInstance().openLog();
                    ZhugeSDK.getInstance().openDebug();
                    ZhugeSDK.getInstance().init(getApplicationContext());
                }

                Intent intent = new Intent(InputInfoActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        mBtnStartHVT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String str = mEtInput.getText().toString();
                if (TextUtils.isEmpty(str)) {
                    Constants.TOTAL_TIME = 100;
                    Toast.makeText(InputInfoActivity.this, "测试次数为默认的100次", Toast.LENGTH_SHORT).show();
                } else {
                    int times = Integer.valueOf(str);
                    Constants.TOTAL_TIME = times;
                    Toast.makeText(InputInfoActivity.this, "测试次数为 " + times + " 次", Toast.LENGTH_SHORT).show();
                }
                HvtActivity.start(InputInfoActivity.this);

            }
        });

        mBtnChangeMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int mode = CommonUtil.getReportPolicyMode(mContext);
                Log.d("MainActivity", "mode:" + mode);
                if (mode == 0) {
                    Constants.REPORT_MODE = 1;
                    CommonUtil.setReportPolicy(mContext, 1, "client");
                    CommonUtil.setReportPolicy(mContext, 1, "server");
                    mTvReportMode.setText("当前发送模式为 实时发送");
                } else {
                    Constants.REPORT_MODE = 0;
                    CommonUtil.setReportPolicy(mContext, 0, "client");
                    CommonUtil.setReportPolicy(mContext, 0, "server");
                    mTvReportMode.setText("当前发送模式为 启动时发送");
                }
            }
        });

        mBtnChangeVersion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String appVersion = mEtAppVersion.getText().toString();
                if (TextUtils.isEmpty(appVersion)) {
                    Toast.makeText(mContext, "AppVersion输入框不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                HMTAgent.setAppVersion(mContext, appVersion);
                mEtAppVersion.setHint("当前AppVersion:" + appVersion);
                mEtAppVersion.setText("");


            }
        });

        mBtnChangeSdk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sdkMode = mEtSdk.getText().toString();
                if (sdkMode.equals("0")) {
                    MobclickAgent.setDebugMode(true);
                    SPUtils.put(InputInfoActivity.this, Constants.TEST_MODE, "0");
                    mEtSdk.setText("");
                    mBtnStart.setText("测试HMT");
                    mEtSdk.setHint("SDK:0 <0-HMT,1-UM,2-TD,3-GI,4-ZG>");
                } else if (sdkMode.equals("1")) {
                    SPUtils.put(InputInfoActivity.this, Constants.TEST_MODE, "1");
                    mEtSdk.setText("");
                    mBtnStart.setText("测试UM");
                    mEtSdk.setHint("SDK:1 <0-HMT,1-UM,2-TD,3-GI,4-ZG>");
                } else if (sdkMode.equals("2")) {
                    SPUtils.put(InputInfoActivity.this, Constants.TEST_MODE, "2");
                    mEtSdk.setText("");
                    mBtnStart.setText("测试TD");
                    mEtSdk.setHint("SDK:2 <0-HMT,1-UM,2-TD,3-GI,4-ZG>");
                } else if (sdkMode.equals("3")) {
                    SPUtils.put(InputInfoActivity.this, Constants.TEST_MODE, "3");
                    mEtSdk.setText("");
                    mBtnStart.setText("测试GI");
                    mEtSdk.setHint("SDK:3 <0-HMT,1-UM,2-TD,3-GI,4-ZG>");
                } else if (sdkMode.equals("4")) {
                    SPUtils.put(InputInfoActivity.this, Constants.TEST_MODE, "4");
                    mEtSdk.setText("");
                    mBtnStart.setText("测试ZG");
                    mEtSdk.setHint("SDK:4 <0-HMT,1-UM,2-TD,3-GI,4-ZG>");
                } else {
                    Toast.makeText(mContext, "输入模式不符合规则", Toast.LENGTH_SHORT).show();
                }
            }
        });

        mBtnDatabaseNum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder stringBuilder = new StringBuilder();
                DataBaseManager.initializeInstance(DataBaseOpenHelper.getInstance(getApplicationContext()));
                SQLiteDatabase database = DataBaseManager.openDatabase();
                Cursor cursor = database.rawQuery("select COUNT(*) from hmtInfo", null);
                cursor.moveToFirst();
                int count = cursor.getInt(0);
                stringBuilder.append("总共" + count + "条数据,");
                cursor.close();
                cursor = null;
                cursor = database.rawQuery("select COUNT(*) from hmtInfo where type = 'act_list'", null);
                cursor.moveToFirst();
                count = cursor.getInt(0);
                stringBuilder.append("act_list = " + count + "条数据,");
                cursor.close();
                cursor = null;
                cursor = database.rawQuery("select COUNT(*) from hmtInfo where type = 'error_list'", null);
                cursor.moveToFirst();
                count = cursor.getInt(0);
                stringBuilder.append("error_list = " + count + "条数据,");
                cursor.close();
                cursor = null;
                cursor = database.rawQuery("select COUNT(*) from hmtInfo where type = 'activity_list'", null);
                cursor.moveToFirst();
                count = cursor.getInt(0);
                stringBuilder.append("activity_list = " + count + "条数据.");
                cursor.close();
                cursor = null;
                cursor = database.rawQuery("select COUNT(*) from hmtInfo where type = 'client_data_list'", null);
                cursor.moveToFirst();
                count = cursor.getInt(0);
                stringBuilder.append("client_data_list = " + count + "条数据.");
                cursor.close();
                cursor = null;
                DataBaseManager.closeDatabase();
                AlertDialog dialog = new AlertDialog.
                        Builder(InputInfoActivity.this
                ).create();
                dialog.setTitle("数据信息");
                dialog.setMessage(stringBuilder.toString());
                dialog.show();

            }
        });
    }

    private void initView() {
        mBtnDatabaseNum = (Button) findViewById(R.id.btn_database_num);
        mEtSdk = (EditText) findViewById(R.id.et_sdk);
        mBtnChangeSdk = (Button) findViewById(R.id.btn_change_sdk);
        mEtAppVersion = (EditText) findViewById(R.id.et_app_version);
        mBtnChangeVersion = (Button) findViewById(R.id.btn_change_appversion);
        mEtInput = (EditText) findViewById(R.id.et_input);
        mBtnStart = (Button) findViewById(R.id.btn_start);
        mBtnStartHVT = (Button) findViewById(R.id.btn_start_hvt);
        mBtnChangeMode = (Button) findViewById(R.id.btn_change_mode);
        mTvReportMode = (TextView) findViewById(R.id.tv_report_mode);
    }
}
