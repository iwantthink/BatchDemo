package hmtdemo.hmt.com.hmtdemo.hmt;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.growingio.android.sdk.collection.GrowingIO;
import com.hmt.analytics.HMTAgent;
import com.hmt.analytics.common.CommonUtil;
import com.hmt.analytics.util.HParams;
import com.tendcloud.tenddata.TCAgent;
import com.umeng.analytics.MobclickAgent;
import com.zhuge.analysis.stat.ZhugeSDK;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import hmtdemo.hmt.com.hmtdemo.R;

import static hmtdemo.hmt.com.hmtdemo.hmt.Constants.params;
import static hmtdemo.hmt.com.hmtdemo.hmt.Constants.sHashMap;
import static hmtdemo.hmt.com.hmtdemo.hmt.Constants.sThrowable;


public class MainActivity extends BaseActivity {

    private static Context mContext;
    private Button mBtnSendClientData;
    private Button mBtnBindMuid;
    private Button mBtnAutoError;
    private Button mBtnManualError;
    private Button mBtnJumpWebview;
    private Button mBtnChangeActivity;
    private Button mBtnSendAction;
    private Button mBtnSendOkhttp;
    private Button mBtnSendHttpReq;
    private Button mBtnChangeMode;
    private TextView mTvTestState;


    public static void start(Activity context) {
        Intent intent = new Intent(context, MainActivity.class);
        context.startActivity(intent);
//        context.finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = getApplicationContext();
        initView();
        initListener();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Constants.IS_AUTO) {
            autoLogic();
        }

        showTestTimes();
    }

    private void showTestTimes() {
        if (Constants.RUNNING_TIME >= Constants.TOTAL_TIME) {
            mTvTestState.setText(Constants.RUNNING_TIME + "次测试已经结束！");
            mTvTestState.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
            Constants.RUNNING_TIME++;

        } else {
            mTvTestState.setText("当前测试第" + Constants.RUNNING_TIME + "次!");
        }
    }

    @Override
    protected void onDestroy() {
        Log.e("testCccc", "onDestroy");
        setContentView(R.layout.activity_main2);
        mContext = null;
        mBtnChangeMode = null;
        mBtnBindMuid = null;
        mBtnSendClientData = null;
        mBtnAutoError = null;
        mBtnManualError = null;
        mBtnJumpWebview = null;
        mBtnChangeActivity = null;
        mBtnSendAction = null;
        mBtnSendOkhttp = null;
        mBtnSendHttpReq = null;
        System.gc();
        unbindDrawables(getWindow().getDecorView());
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            if (!Constants.IS_AUTO) {
                manualLogic();
            } else {
                autoLogic();
            }
        }
    }

    private void manualLogic() {
        if (Constants.RUNNING_TIME < Constants.TOTAL_TIME) {
            Log.d("MainActivity", "Constants.RUNNING_TIME:" + Constants.RUNNING_TIME);
            Constants.RUNNING_TIME++;
            String testMode = (String) SPUtils.get(MainActivity.this, Constants.TEST_MODE, "0");
            if (testMode.equals("0")) {
                HMTAgent.onAction(MainActivity.this, "login1", params);
                HMTAgent.onError(MainActivity.this, "获取活动信息出错");
            } else if (testMode.equals("1")) {
                MobclickAgent.onEvent(MainActivity.this, "action_login", sHashMap);
                MobclickAgent.reportError(MainActivity.this, "获取活动信息出错");
            } else if (testMode.equals("2")) {
                //talkingData
                TCAgent.onEvent(MainActivity.this, "Login1", "login2", sHashMap);
                TCAgent.onError(MainActivity.this, sThrowable);
            } else if (testMode.equals("3")) {
                GrowingIO.startTracing(MainActivity.this, "");
            } else if (testMode.equals("4")) {
                //定义与事件相关的属性信息
                JSONObject eventObject = null;
                try {
                    eventObject = new JSONObject();
                    eventObject.put("商品分类", "手机");
                    eventObject.put("商品名称", "iPhone7 64g");
                    eventObject.put("数量", 2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                //记录事件,以购买为例
                ZhugeSDK.getInstance().track(getApplicationContext(), "Login1", eventObject);
            }
            SeconedActivity.start(MainActivity.this);
        }
    }

    private void autoLogic() {
        if (BaseApplication.IS_FIRST.compareAndSet(false, true)) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(0);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            SeconedActivity.start(MainActivity.this);
                        }
                    });
                }
            }).start();
        } else {

            HMTAgent.onAction(MainActivity.this, "Login1", params);
            HMTAgent.onError(MainActivity.this, "获取活动信息出错");
        }
    }

    private void initListener() {

        mBtnChangeMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int mode = CommonUtil.getReportPolicyMode(mContext);
                Log.d("MainActivity", "mode:" + mode);
                if (mode == 0) {
                    CommonUtil.setReportPolicy(mContext, 1, "client");
                    CommonUtil.setReportPolicy(mContext, 1, "server");
                    Toast.makeText(mContext, "当前发送模式为 实时发送", Toast.LENGTH_SHORT).show();
                } else {
                    CommonUtil.setReportPolicy(mContext, 0, "client");
                    CommonUtil.setReportPolicy(mContext, 0, "server");
                    Toast.makeText(mContext, "当前发送模式为 启动时发送", Toast.LENGTH_SHORT).show();
                }
            }
        });

        mBtnBindMuid.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String muid = HMTAgent.bindMuid(mContext, "muid");
                Log.d("MainActivity", "muid = " + muid);
            }
        });

        mBtnSendClientData.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                HMTAgent.postClientData(mContext);
            }
        });


        mBtnAutoError.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
//                int i = 1 / 0;
            }
        });

        mBtnManualError.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                try {
                    int i = 1 / 0;
                } catch (Exception e) {
                    String[] a = new String[4];
                    a[0] = "0";
                    a[1] = "1";
                    a[2] = "2";
                    a[3] = "你好";
                    HParams property = new HParams();
                    property.setParams("addIntegral", a);
                    property.setParams("name", "error1");
                    property.setParams("name", "error2");
                    HMTAgent.onError(mContext, e.getMessage(), property);
                }

            }
        });

        mBtnJumpWebview.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                WebActivity.start(MainActivity.this);
            }
        });

        mBtnChangeActivity.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                SeconedActivity.start(MainActivity.this);
            }
        });

        mBtnSendAction.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                HParams property = new HParams();
                property.setParams("title", "百度新闻");
                property.setParams("desc", "第一条新闻");
                property.setParams("name", "error");
                HMTAgent.onAction(mContext, "自定义事件", property);
            }
        });

        mBtnSendOkhttp.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new Thread() {
                    @Override
                    public void run() {
                        //sendOkHttp("http://www.baidu.com");
                    }
                }.start();
            }
        });

        mBtnSendHttpReq.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new Thread() {
                    @Override
                    public void run() {
                        String str = getURLResponse("https://www.baidu.com");
                        Log.d("MainActivity", str);
                    }
                }.start();
            }
        });
    }

    private void initView() {
        mTvTestState = (TextView) findViewById(R.id.tv_test_state);
        mBtnChangeMode = (Button) findViewById(R.id.btn_change_mode);
        mBtnBindMuid = (Button) findViewById(R.id.btn_bind_muid);
        mBtnSendClientData = (Button) findViewById(R.id.btn_send_client_data);
        mBtnAutoError = (Button) findViewById(R.id.btn_auto_error);
        mBtnManualError = (Button) findViewById(R.id.btn_manual_error);
        mBtnJumpWebview = (Button) findViewById(R.id.btn_jump_webview);
        mBtnChangeActivity = (Button) findViewById(R.id.btn_change);
        mBtnSendAction = (Button) findViewById(R.id.btn_send_action);
        mBtnSendOkhttp = (Button) findViewById(R.id.btn_send_okhttp);
        mBtnSendHttpReq = (Button) findViewById(R.id.btn_send_http_req);
    }

    private String getURLResponse(String urlString) {
        HttpURLConnection conn = null;
        InputStream is = null;
        String resultData = "";
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setUseCaches(false);
            conn.setRequestMethod("GET");
            is = conn.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader bufferReader = new BufferedReader(isr);
            String inputLine = "";
            while ((inputLine = bufferReader.readLine()) != null) {
                resultData += inputLine + "\n";
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }

        return resultData;
    }
}
