package hmtdemo.hmt.com.hmtdemo.hmt;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import hmtdemo.hmt.com.hmtdemo.R;

/*import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;*/

public class SeconedActivity extends BaseActivity {

    private Context mContext;
//    private Button mBtnSendClientData;
//    private Button mBtnBindMuid;
//    private Button mBtnAutoError;
//    private Button mBtnManualError;
//    private Button mBtnJumpWebview;
//    private Button mBtnChangeActivity;
//    private Button mBtnSendAction;
//    private Button mBtnSendOkhttp;
//    private Button mBtnSendHttpReq;


    public static void start(Activity context) {
        Intent intent = new Intent(context, SeconedActivity.class);
        context.startActivity(intent);
//        context.finish();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_seconed);
        setContentView(R.layout.activity_main2);
        mContext = getApplicationContext();
        initView();
        initListener();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Constants.IS_AUTO) {
            autoLogic();
        }
    }

    @Override
    protected void onDestroy() {
//        setContentView(R.layout.activity_main2);
        Log.e("testCccc", "onDestroy");

        mContext = null;
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            if (!Constants.IS_AUTO) {
                manualLogic();
            }
        }
    }

    private void manualLogic() {
        if (Constants.RUNNING_TIME <= Constants.TOTAL_TIME) {
            MainActivity.start(SeconedActivity.this);
        } else {
//            finish();
            android.os.Process.killProcess(android.os.Process.myPid());
        }
    }

    private void autoLogic() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.start(SeconedActivity.this);
                    }
                });
            }
        }).start();
    }

    private void initListener() {
//        mBtnBindMuid.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                String muid = HMTAgent.bindMuid(mContext, "muid");
//                Log.d("MainActivity", "muid = " + muid);
//            }
//        });
//
//        mBtnSendClientData.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                HMTAgent.postClientData(mContext);
//            }
//        });
//
//
//        mBtnAutoError.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
////                int i = 1 / 0;
//            }
//        });
//
//        mBtnManualError.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                try {
//                    int i = 1 / 0;
//                } catch (Exception e) {
//                    String[] a = new String[4];
//                    a[0] = "0";
//                    a[1] = "1";
//                    a[2] = "2";
//                    a[3] = "你好";
//                    HParams property = new HParams();
//                    property.setParams("addIntegral", a);
//                    property.setParams("name", "error1");
//                    property.setParams("name", "error2");
//                    HMTAgent.onError(mContext, e.getMessage(), property);
//                }
//
//            }
//        });
//
//        mBtnJumpWebview.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                WebActivity.start(SeconedActivity.this);
//            }
//        });
//
//        mBtnChangeActivity.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                MainActivity.start(SeconedActivity.this);
//            }
//        });
//
//        mBtnSendAction.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                HParams property = new HParams();
//                property.setParams("title", "百度新闻");
//                property.setParams("desc", "第一条新闻");
//                property.setParams("name", "error");
//                HMTAgent.onAction(mContext, "自定义事件", property);
//            }
//        });
//
//        mBtnSendOkhttp.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                new Thread() {
//                    @Override
//                    public void run() {
//                        //sendOkHttp("http://www.baidu.com");
//                    }
//                }.start();
//            }
//        });
//
//        mBtnSendHttpReq.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                new Thread() {
//                    @Override
//                    public void run() {
//                        String str = getURLResponse("https://www.baidu.com");
//                        Log.d("MainActivity", str);
//                    }
//                }.start();
//            }
//        });
    }

    private void initView() {
//        mBtnBindMuid = (Button) findViewById(R.id.btn_bind_muid);
//        mBtnSendClientData = (Button) findViewById(R.id.btn_send_client_data);
//        mBtnAutoError = (Button) findViewById(R.id.btn_auto_error);
//        mBtnManualError = (Button) findViewById(R.id.btn_manual_error);
//        mBtnJumpWebview = (Button) findViewById(R.id.btn_jump_webview);
//        mBtnChangeActivity = (Button) findViewById(R.id.btn_change);
//        mBtnSendAction = (Button) findViewById(R.id.btn_send_action);
//        mBtnSendOkhttp = (Button) findViewById(R.id.btn_send_okhttp);
//        mBtnSendHttpReq = (Button) findViewById(R.id.btn_send_http_req);
    }




   /* private void sendOkHttp(String url){
        OkHttpClient mOkHttpClient = new OkHttpClient();
        final Request request = new Request.Builder()
                .url(url)
                .build();
        Call call = mOkHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Request request, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(final Response response) throws IOException {
                String htmlStr = response.body().string();
                int code = response.code();
                Log.e("OkHttp==>htmlStr:", htmlStr);
                Log.e("OkHttp==>code:", code + "");
            }
        });
    }*/

    private String getURLResponse(String urlString) {
        HttpURLConnection conn = null;
        InputStream is = null;
        String resultData = "";
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setUseCaches(false);
            conn.setRequestMethod("GET");
            is = conn.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader bufferReader = new BufferedReader(isr);
            String inputLine = "";
            while ((inputLine = bufferReader.readLine()) != null) {
                resultData += inputLine + "\n";
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }

        return resultData;
    }
}
